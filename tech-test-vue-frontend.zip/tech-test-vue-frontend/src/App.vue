<script setup lang="ts">
</script>

<template>
  <div>
    <h1>3D Group technical assessment - Vue frontend</h1>
    <p>
      Please read the Readme. Once you are ready to make changes, replace the
      contents of this component.
    </p>
  </div>
</template>

<style scoped>
</style>
