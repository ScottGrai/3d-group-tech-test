import express from "express";

/**
 * Please read the README before making changes to this file.
 * Once ready to begin the task, feel free to remove this comment.
 */

const app = express();
const port = 3000;

app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", /* Set the value */"");
    next();
})

app.get("/", /* Set the route handler */);

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});