function App() {
  return (
    <>
      <h1>3D Group technical assessment - React frontend</h1>
      <p>
        Please read the Readme. Once you are ready to make changes, replace the
        contents of this component.
      </p>
    </>
  );
}

export default App;
